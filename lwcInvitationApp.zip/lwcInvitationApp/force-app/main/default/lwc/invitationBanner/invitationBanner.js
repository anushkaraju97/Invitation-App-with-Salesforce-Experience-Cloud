import { LightningElement, wire, track } from 'lwc';
import marriageInvitationAssets from '@salesforce/resourceUrl/marriageInvitationAssets'
import CONFETTI from '@salesforce/resourceUrl/confetti'
import {loadScript} from 'lightning/platformResourceLoader'
import getInvitationDetailsById from '@salesforce/apex/invitationController.getInvitationDetailsById'
export default class InvitationBanner extends LightningElement {
    theme = 'theme1'
    recordId = 'a0Bak00000Txu8k';
    @track invitationdetails = {};

    facebookUrl=''
    twitterUrl=''
    instagramUrl=''
    greetingMessage=''
    participants=''
    intro=''
    evtDateTime=''
    isConfettiLoaded = false

    //Paths to the static resources
    instagramImage = marriageInvitationAssets+'/instagram.svg'
    facebookImage = marriageInvitationAssets+'/facebook.svg'
    twitterImage = marriageInvitationAssets+'/twitter.svg'

    //countdown properties
    intervalId
    days=0
    minutes=0
    hours=0
    seconds=0

    connectedCallback(){
        let invitationId = new URL(location.href).searchParams.get('invitationid')
        if(invitationId){
            this.recordId = invitationId
        }
    }

    get bannerImage() {
        let themeName = marriageInvitationAssets + `/${this.theme}.jpeg`
        return `background-image:url(${themeName})`
    }

    //Dynamically setting background image style for the banner
    @wire(getInvitationDetailsById, {Id: '$recordId'})
    invitationDetailHandler({data, error}){
        if(data){
            console.log("invitationDetailHandler", JSON.stringify(data))
            this.theme = data.Theme__c
            this.invitationDetails = {...data}
            this.facebookUrl = data.Facebook_Url__c
            this.instagramUrl = data.Instagram_Url__c
            this.twitterUrl = data.Twitter_Url__c
            this.greetingMessage = data.Greeting_Message__c
            this.participants = data.Event_Participants__c
            this.intro = data.Event_Introduction__c
            this.evtDateTime = data.Event_Date_and_Time__c
            this.countdownTimer(data.Event_Date_and_Time__c)
        }
        if(error){
            console.error(error)
        }
    }

    //function to start the countdown timer
    countdownTimer(targetDate){
        this.intervalId = setInterval(() => {
            //get the current time
            const currentTime = new Date().getTime()
            const targetTime = new Date(targetDate).getTime()

            //calculate the time difference
            const timeDifference = targetTime - currentTime

            this.days = Math.floor(timeDifference/(1000*60*60*24))
            this.hours = Math.floor((timeDifference % (1000*60*60*24)) / (1000*60*60))
            this.minutes = Math.floor((timeDifference % (1000*60*60)) / (1000*60))
            this.seconds = Math.floor((timeDifference % (1000*60)) / (1000))

            if(timeDifference <=0){
                clearInterval(this.intervalId)
            }
        },1000)
    }

    renderedCallback(){
        if(!this.isConfettiLoaded){
            loadScript(this, CONFETTI).then(() => {
                this.isConfettiLoaded = true
                console.log("LOADED Succcessfully")
                if (window.JSConfetti) {
                    const jsConfetti = new window.JSConfetti();
                    jsConfetti.addConfetti();
                } else {
                    console.error("JSConfetti is not available after loading.");
                }
            }).catch(error => {
                console.error("Error loading Confetti:", error.message, error.stack);
            })
        }
        
    }
}