declare module "@salesforce/apex/invitationController.getInvitationDetailsById" {
  export default function getInvitationDetailsById(param: {Id: any}): Promise<any>;
}
declare module "@salesforce/apex/invitationController.getProgramDetailsByInvitationId" {
  export default function getProgramDetailsByInvitationId(param: {Id: any}): Promise<any>;
}
declare module "@salesforce/apex/invitationController.getInvitationAddress" {
  export default function getInvitationAddress(param: {Id: any}): Promise<any>;
}
declare module "@salesforce/apex/invitationController.getRSVPDetails" {
  export default function getRSVPDetails(param: {Id: any}): Promise<any>;
}
declare module "@salesforce/apex/invitationController.getResponsePicklistValues" {
  export default function getResponsePicklistValues(): Promise<any>;
}
declare module "@salesforce/apex/invitationController.submitResponse" {
  export default function submitResponse(param: {InvitationId: any, Name: any, Email: any, Phone: any, Response: any, additionalGuests: any, additionalComment: any}): Promise<any>;
}
